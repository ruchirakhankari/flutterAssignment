class Featured {
  final int id;
  final String body;
  final int postId;
  Featured({
    required this.id,
    required this.body,
    required this.postId,
  });
}